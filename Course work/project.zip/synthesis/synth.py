"""
CSC410 Final Project: Enumerative Synthesizer
by Victor Nicolet and Danya Lette

Fill in this file to complete the synthesis portion
of the assignment.
"""

from collections import defaultdict
from typing import Dict, Mapping
from z3 import *
from lang.ast import *
import random
import queue


class Synthesizer():
    """
    This class is has three methods `synth_method_1`, `synth_method_2` or
    `synth_method_3` for generating expression for a program's holes.

    You may also choose to add data attributes and methods to this class
    to enable instances of `Synthesizer` to remember information about
    previous runs.

    Calling `synth_method_1`, `synth_method_2` or `synth_method_3` should
    produce a new set of hole completions at each call for a given
    `Synthesizer` instance.
    For example, suppose the program p contains one hole `h1` with the
    grammar `[ G : int -> G + G | 0 | 1 ]`. Then, the following sequence
    is a possible execution:
    ```
    > s = Synthesizer(p)
    > s.synth_method_1()
    { "h1" : 0 }
    > s.synth_method_1()
    { "h1" : 1 }
    > s.synth_method_1()
    { "h1" : 0 + 1 }
    ...
    ```
    Each call produces a hole completion. The returned object should
    be a mapping from the hole id (its name) to the expression of the
    hole.
    Each `synth_method_..` should implement a different enumeration
    strategy (e.g. depth first, breadth first, constants-first,
    variables-first...).

    **Don't forget that we expect your third method to be the best on
    average!**

    *Hint*: the method `hole_can_use` in the `Program` class returns the
    set of variables that a given hole can use in its completions.
    e.g. `prog.hole_can_use("h1")` returns the variables that "h1" can use.
    """

    def __init__(self, ast: Program):
        """
        Initialize the Synthesizer.
        The Synthesizer can have a state or other data attributes and
        methods to remember which programs have been synthesized before.
        """
        self.state = None
        # The synthesizer is initialized with the program ast it needs
        # to synthesize hole completions for.
        self.ast = ast

    # programs have already been generated.
        self.state_tracker = []
        self.iteration_method_1 = 1
        self.iteration_method_2 = 1
        self.iteration_method_3 = 1
        self.iter_2_prev = None
        self.iter_3_prev = None

    def synth_method_1(self,) -> Mapping[str, Expression]:
        """
        Returns a map from each hole id in the program `self.ast`
        to an expression (method 1).

        Use a random dfs search to iterate through the rules and return expression mapping
        We'll try to search deeper to lower levels and each call will increase the search level depth,
        After we get to the expected depth (iteration_method_1) set by the counter, we'll randomly choose
        one of the rules at this level as the final answer

        ## Details of implementation when getting different types:

        - grammer -> rules -> productionRule-> productions -> expression -> might contain var + var

        - define ret dict

        - store variable to var_list when having Variable

        - skip Expression

        - when meet hole, use helper(...)

        - helper(expr, var_list, ret): -> append to final ret dict

            - GrammarVar -> use previously stored var in prog (ast.assignments)

            - unaryExpression -> unaryExpression

            - BinaryExpression -> normal var? expression, rule var ? continue or find a termination var

            - GrammarInteger -> search previously stored integer var in prog

            - the choice of helper method is determined by the self.iteration_method_1

        """
        ret = dict()
        self.iteration_method_1 = (self.iteration_method_1 + 1) % 20
        cur_vars = []
        # iterate each children of ast and collect variables, also process hole when finding holes
        for expr in self.ast.children():
            if isinstance(expr, Variable):
                cur_vars.append(expr)
            elif isinstance(expr, Assignment):
                cur_vars.append(expr.var)
            elif isinstance(expr, HoleDeclaration):
                hole_name = expr.var.name
                temp_rules = dict()
                symbol_type = dict()
                for rule in expr.grammar.rules:
                    # collect all rules according to the rule name
                    temp_rules[rule.symbol.name] = rule.productions
                    symbol_type[rule.symbol.name] = str(rule.symbol.type)
                target_rule = expr.grammar.rules[0]
                random_expr = target_rule.productions[self.iteration_method_1 % len(target_rule.productions)]
                rule_symbol = target_rule.symbol.name
                ret[hole_name] = self._process_random_target_helper(rule_symbol, random_expr,
                                                                    cur_vars, temp_rules, symbol_type, 0)
        return ret

    """
    Helper method to process the rules

    - @rule_symbol: the current production name being processed

    - @random_expr: the current expression being processed

    - @var_list: a list of existing variables defined

    - @temp_rules: the mapping of production name to its rule

    - @type_map: the type of each production

    - @iter_depth: the depth we need
    """

    def _process_random_target_helper(self,
                                      rule_symbol: str, random_expr, var_list: List[Variable],
                                      temp_rules: Dict[str, List[Expression]],
                                      type_map: Dict[str, str], iter_depth: int) -> Expression:
        rule_type = type_map[rule_symbol]
        iter_depth += 1
        if isinstance(random_expr, GrammarVar):
            vars = var_list
            if rule_type == "int":
                choice_lst = list(filter(lambda x: str(x.type) == "int", vars))
            else:
                choice_lst = list(filter(lambda x: str(x.type) == "bool", vars))
            var_choice = random.choice(choice_lst)
            return VarExpr(var_choice)

        if isinstance(random_expr, GrammarInteger):
            vars = var_list
            choice_lst = list(filter(lambda x: str(x.type) == "int", vars))
            var_choice = random.choice(choice_lst)
            return VarExpr(var_choice)

        if isinstance(random_expr, IntConst):
            return random_expr

        if isinstance(random_expr, BoolConst):
            return random_expr

        if isinstance(random_expr, VarExpr):
            if random_expr.name not in temp_rules:
                return random_expr
            new_rules = temp_rules[random_expr.name]
            new_random_expr = random.choice(new_rules)
            if iter_depth > self.iteration_method_1:
                new_random_expr = self._find_constant(new_rules, temp_rules)
            return self._process_random_target_helper(random_expr.name, new_random_expr,
                                                      var_list, temp_rules, type_map, iter_depth)

        if isinstance(random_expr, UnaryExpr):
            return UnaryExpr(random_expr.operator,
                             self._process_random_target_helper(rule_symbol, random_expr.operand, var_list,
                                                                temp_rules, type_map, iter_depth))

        if isinstance(random_expr, Ite):
            return Ite(self._process_random_target_helper(rule_symbol, random_expr.cond,
                                                          var_list, temp_rules, type_map, iter_depth),
                       self._process_random_target_helper(rule_symbol, random_expr.true_br,
                                                          var_list, temp_rules, type_map, iter_depth),
                       self._process_random_target_helper(rule_symbol, random_expr.false_br,
                                                          var_list, temp_rules, type_map, iter_depth))

        if isinstance(random_expr, BinaryExpr):
            return BinaryExpr(random_expr.operator,
                              self._process_random_target_helper(rule_symbol, random_expr.left_operand,
                                                                 var_list, temp_rules, type_map, iter_depth),
                              self._process_random_target_helper(rule_symbol, random_expr.right_operand,
                                                                 var_list, temp_rules, type_map, iter_depth))
        # this never reached

        print("<<<<<<<<<<<<<This should never be reached!>>>>>>>>>>>>>")
        print("reached statement is: ")
        print(type(random_expr).__name__)
        print(random_expr)
        return None

    """
    helper method to find the nearest non-recursive rule on the tree
    """
    def _find_constant(self, rules, rule_dict):
        for rule in rules:
            if self._is_constant(rule, rule_dict):
                return rule
        return random.choice(rules)

    """
    helper method to check if the current rule is non-recursive
    """
    def _is_constant(self, rule, rule_dict) -> bool:
        if isinstance(rule, GrammarVar):
            return True
        if isinstance(rule, GrammarInteger):
            return True
        if isinstance(rule, IntConst):
            return True
        if isinstance(rule, BoolConst):
            return True
        if isinstance(rule, VarExpr):
            return not (rule.name in rule_dict)
        return False

    def synth_method_2(self,) -> Mapping[str, Expression]:
        """
        Returns a map from each hole id in the program `self.ast`
        to an expression (method 2).
        yield implementation of method 1
        BFS search to iterate through the whole possible combinations of rules, we'll define
        a counter first to indicate the number of expression we're going to skip, each call will increment
        this counter by 1, and we'll search levels by levels, return the corresponding expression when reaching
        the destination(when the number of items visited is just larger than the counter)
        """

        ret = dict()
        self.iteration_method_2 = (self.iteration_method_2 + 1) % 1000
        cur_vars = []
        for expr in self.ast.children():
            if isinstance(expr, Variable):
                cur_vars.append(expr)
            elif isinstance(expr, Assignment):
                cur_vars.append(expr.var)
            elif isinstance(expr, HoleDeclaration):
                hole_name = expr.var.name
                temp_rules = dict()
                symbol_type = dict()
                for rule in expr.grammar.rules:
                    temp_rules[rule.symbol.name] = rule.productions
                    symbol_type[rule.symbol.name] = str(rule.symbol.type)
                target_rule = expr.grammar.rules[0]
                rule_symbol = target_rule.symbol.name
                ret[hole_name] = self._process_bfs_target_helper(rule_symbol,
                                                                 self.ast.hole_can_use(hole_name),
                                                                 temp_rules, symbol_type, self.iteration_method_2)
        if self.iter_2_prev is not None and self.iter_2_prev == ret:
            return self.synth_method_2()
        else:
            self.iter_2_prev = ret
        return ret

    """
    Helper method for bfs search
    @rule_symbol: the production name
    @var_list: the list with existing defined variables
    @temp_rules: the mapping from production name to its rules
    @type_map: the mapping from production name to its type
    @iter_depth: the counter as mentioned in the previous doc of method2

    In order to be able to restore the whole expression from the lower level,
    this method applies a trace technique to mark some specific point and store its trace
    during the bfs search, when the search finishes, the lower level expression can be
    restored to a whole expression according to its trace
    """
    def _process_bfs_target_helper(self,
                                   rule_symbol: str, var_list: List[Variable],
                                   temp_rules: Dict[str, List[Expression]],
                                   type_map: Dict[str, str], iter_depth: int) -> Expression:
        q = []
        special_struct_version = 1  # unique identifier for a specific trace
        cur_symbol = rule_symbol
        rules = temp_rules[cur_symbol]
        final_target = None
        for rule in rules:
            q.append((cur_symbol, rule, []))
        # start bfs
        cached = []  # use cached to store the traced expression
        while len(q) > 0:
            symbol, rule, trace = q.pop(0)
            leaf = None
            iter_depth -= 1
            cur_rule_type = type_map[symbol]
            if isinstance(rule, GrammarVar):
                vars = var_list
                if cur_rule_type == "int":
                    choice_lst = list(filter(lambda x: str(x.type) == "int", vars))
                else:
                    choice_lst = list(filter(lambda x: str(x.type) == "bool", vars))
                var_choice = random.choice(choice_lst)
                leaf = (symbol, VarExpr(var_choice), trace)
            elif isinstance(rule, GrammarInteger):
                vars = var_list
                choice_lst = list(filter(lambda x: str(x.type) == "int", vars))
                var_choice = random.choice(choice_lst)
                leaf = (symbol, VarExpr(var_choice), trace)
            elif isinstance(rule, IntConst):
                leaf = (symbol, rule, trace)
            elif isinstance(rule, BoolConst):
                leaf = (symbol, rule, trace)
            elif isinstance(rule, UnaryExpr):
                leaf = (symbol, rule.operand, trace + [("Unary", rule.operator)])
            elif isinstance(rule, BinaryExpr):
                # add the trace and process the version number
                new_q_left = (symbol, rule.left_operand,
                              trace + [("Binary", rule.operator, "left", special_struct_version)])
                q.append(new_q_left)
                new_q_right = (symbol, rule.right_operand,
                               trace + [("Binary", rule.operator, "right", special_struct_version)])
                q.append(new_q_right)
                special_struct_version += 1
            elif isinstance(rule, Ite):
                new_q_cond = (symbol, rule.cond,
                              trace + [("Ite", "cond", special_struct_version)])
                new_q_true = (symbol, rule.true_br,
                              trace + [("Ite", "tr", special_struct_version)])
                new_q_false = (symbol, rule.false_br,
                               trace + [("Ite", "fr", special_struct_version)])
                special_struct_version += 1
                q.append(new_q_cond)
                q.append(new_q_true)
                q.append(new_q_false)
            elif isinstance(rule, VarExpr):
                if rule.var.name not in temp_rules:
                    leaf = (symbol, rule, trace)  # this is the leaf node (non-recursive)
                else:
                    new_symbol = rule.name
                    new_rules = temp_rules[rule.name]
                    if iter_depth <= 0:
                        r = self._find_constant(new_rules, temp_rules)
                        if not r:
                            c = (new_symbol, new_rules[0], trace)
                        else:
                            c = (new_symbol, r, trace)
                        q.append(c)
                    else:
                        for r in new_rules:
                            q.append((new_symbol, r, trace))
            if leaf is not None and iter_depth <= 0 and final_target is None \
                    and isinstance(leaf[1], Expression) and self._is_constant(leaf[1], temp_rules):
                final_target = leaf
            if len(q) == 0 and final_target is None:
                final_target = leaf
            if leaf is not None:
                cached.append(leaf)

        symbol, final_expr, traces = final_target
        # start trace back after finding a solution at lower level
        return self._trace_back(final_expr, traces, cached, temp_rules)
    """
    helper method to trace back from the initial_expr and return the complete expression according to
    its trace record

    - @initial_expr: the start expression

    - @traces: the trace record

    - @cached: all traced records

    - @temp_rules: the mapping from production name to rules

    - @version: specific stop point when reaching a trace point, will directly return the expression if

    the specifc trace point is found
    """
    def _trace_back(self, initial_expr, traces, cached, temp_rules, version=-1):
        if len(traces) == 0:
            return initial_expr
        cur_trace = traces[-1]  # the current trace record we're processing
        trace_name = cur_trace[0]
        # if the version matches, meaning we finally get to the desired trace point,
        # directly return the result
        if len(cur_trace) > 2 and version == cur_trace[-1]:
            return initial_expr

        if trace_name == "Binary":
            # process if the trace point is a binary
            version_number = cur_trace[3]
            statement = cur_trace[2]  # get left or right
            operator = cur_trace[1]
            statements = []
            state_check = set()
            state_check.add(statement)
            for leaf in cached:
                expr = leaf[1]
                track = leaf[2]
                if self._is_constant(expr, temp_rules) and isinstance(expr, Expression):
                    for t in track:
                        if len(t) > 2 and t[-1] == version_number and t[0] == "Binary" and t[2] not in state_check:
                            statements.append((expr, t[2], track))
                            state_check.add(t[2])
                            break
            left = None
            right = None
            if statement == "left":
                left = initial_expr
            else:
                right = initial_expr
            for s in statements:
                if s[1] == "left":
                    # trace back the left
                    left = self._trace_back(s[0], s[2], cached, temp_rules, version_number)
                if s[1] == "right":
                    # trace back the right
                    right = self._trace_back(s[0], s[2], cached, temp_rules, version_number)
            return self._trace_back(BinaryExpr(operator, left, right), traces[:-1], cached, temp_rules, version)
        elif trace_name == "Ite":
            # process if the trace point is a Ite
            version_number = cur_trace[2]
            statement = cur_trace[1]
            statements = []
            state_check = set()
            state_check.add(statement)
            for leaf in cached:
                expr = leaf[1]
                track = leaf[2]
                if self._is_constant(expr, temp_rules) and isinstance(expr, Expression):
                    for t in track:
                        if len(t) > 2 and t[-1] == version_number and t[0] == "Ite" and t[1] not in state_check:
                            statements.append((expr, t[1], track))
                            state_check.add(t[1])
                            break
            cond = None
            tr = None
            fr = None
            if statement == "cond":
                cond = initial_expr
            elif statement == "tr":
                tr = initial_expr
            elif statement == "fr":
                fr = initial_expr
            if fr is None:
                fr = tr
            if tr is None:
                tr = fr
            for s in statements:
                if s[1] == "cond":
                    # trace the cond expression
                    cond = self._trace_back(s[0], s[2], cached, temp_rules, version_number)
                if s[1] == "tr":
                    tr = self._trace_back(s[0], s[2], cached, temp_rules, version_number)
                if s[1] == "fr":
                    fr = self._trace_back(s[0], s[2], cached, temp_rules, version_number)
            # join them together and continue
            return self._trace_back(Ite(cond, tr, fr), traces[:-1], cached, temp_rules, version)

        elif trace_name == "Unary":
            operator = cur_trace[1]
            return self._trace_back(UnaryExpr(operator, initial_expr), traces[:-1], cached, temp_rules, version)

    def synth_method_3(self,) -> Mapping[str, Expression]:
        """
        Returns a map from each hole id in the program `self.ast`
        to an expression (method 3).

        Similar to method 2, but instead of directly using bfs, we'll apply a constant-first strategy
        Instead of eagerly iterate one level one by one, we'll first sort the whole levels by checking
        if each expression is constant or not, we'll first visit those non-recursive expressions and then
        expanding the rest of the recursive rules, thus reducing as many layers as possible since our skip count
        is limited
        """
        ret = dict()
        self.iteration_method_3 = (self.iteration_method_3 + 1) % 1000
        cur_vars = []
        for expr in self.ast.children():
            if isinstance(expr, Variable):
                cur_vars.append(expr)
            elif isinstance(expr, Assignment):
                cur_vars.append(expr.var)
            elif isinstance(expr, HoleDeclaration):
                hole_name = expr.var.name
                temp_rules = dict()
                symbol_type = dict()
                for rule in expr.grammar.rules:
                    temp_rules[rule.symbol.name] = rule.productions
                    symbol_type[rule.symbol.name] = str(rule.symbol.type)
                target_rule = expr.grammar.rules[0]
                rule_symbol = target_rule.symbol.name
                ret[hole_name] = self._process_bfs_target_helper_1(rule_symbol,
                                                                   cur_vars, temp_rules, symbol_type, self.iteration_method_3)
        if self.iter_3_prev is not None and self.iter_3_prev == ret:
            return self.synth_method_3()
        else:
            self.iter_3_prev = ret
        return ret
    """
    Helper method to implement the constant-first search
    parameter description: same as _process_bfs_target_helper
    """
    def _process_bfs_target_helper_1(self,
                                     rule_symbol: str, var_list: List[Variable],
                                     temp_rules: Dict[str, List[Expression]],
                                     type_map: Dict[str, str], iter_depth: int) -> Expression:
        q = queue.PriorityQueue()  # use priority queue to sort the rules in the same level
        special_struct_version = 1
        cur_symbol = rule_symbol
        rules = temp_rules[cur_symbol]
        final_target = None
        for rule in rules:
            wrapper = ComparableWrapper((cur_symbol, rule, [], 0))
            q.put((self._calculate_weight(0, temp_rules, rule), wrapper))
        # start bfs
        cached = []
        while q.qsize() > 0:
            _, val = q.get()
            symbol, rule, trace, layer = val.get_value()
            leaf = None
            iter_depth -= 1
            cur_rule_type = type_map[symbol]
            if isinstance(rule, GrammarVar):
                vars = var_list
                if cur_rule_type == "int":
                    choice_lst = list(filter(lambda x: str(x.type) == "int", vars))
                else:
                    choice_lst = list(filter(lambda x: str(x.type) == "bool", vars))
                var_choice = random.choice(choice_lst)
                leaf = (symbol, VarExpr(var_choice), trace)
            elif isinstance(rule, GrammarInteger):
                vars = var_list
                choice_lst = list(filter(lambda x: str(x.type) == "int", vars))
                var_choice = random.choice(choice_lst)
                leaf = (symbol, VarExpr(var_choice), trace)
            elif isinstance(rule, IntConst):
                leaf = (symbol, rule, trace)
            elif isinstance(rule, BoolConst):
                leaf = (symbol, rule, trace)
            elif isinstance(rule, UnaryExpr):
                leaf = (symbol, rule.operand, trace + [("Unary", rule.operator)])
            elif isinstance(rule, BinaryExpr):
                new_q_left = (symbol, rule.left_operand,
                              trace + [("Binary", rule.operator, "left", special_struct_version)], layer + 1)
                new_q_wrapper = (self._calculate_weight(layer + 1, temp_rules, rule.left_operand),
                                 ComparableWrapper(new_q_left))
                q.put(new_q_wrapper)
                new_q_right = (symbol, rule.right_operand,
                               trace + [("Binary", rule.operator, "right", special_struct_version)], layer + 1)
                new_q_wrapper = (self._calculate_weight(layer + 1, temp_rules, rule.right_operand),
                                 ComparableWrapper(new_q_right))
                q.put(new_q_wrapper)
                special_struct_version += 1
            elif isinstance(rule, Ite):
                new_q_cond = (symbol, rule.cond,
                              trace + [("Ite", "cond", special_struct_version)], layer + 1)
                new_q_true = (symbol, rule.true_br,
                              trace + [("Ite", "tr", special_struct_version)], layer + 1)
                new_q_false = (symbol, rule.false_br,
                               trace + [("Ite", "fr", special_struct_version)], layer + 1)
                special_struct_version += 1
                new_q_con_wrapper = (self._calculate_weight(layer + 1, temp_rules, rule.cond),
                                     ComparableWrapper(new_q_cond))
                q.put(new_q_con_wrapper)
                new_q_con_wrapper = (self._calculate_weight(layer + 1, temp_rules, rule.true_br),
                                     ComparableWrapper(new_q_true))
                q.put(new_q_con_wrapper)
                new_q_con_wrapper = (self._calculate_weight(layer + 1, temp_rules, rule.false_br),
                                     ComparableWrapper(new_q_false))
                q.put(new_q_con_wrapper)
            elif isinstance(rule, VarExpr):
                if rule.var.name not in temp_rules:
                    leaf = (symbol, rule, trace)
                else:
                    new_symbol = rule.name
                    new_rules = temp_rules[rule.name]
                    if iter_depth <= 0:
                        r = self._find_constant(new_rules, temp_rules)
                        if not r:
                            c = (new_symbol, new_rules[0], trace, layer + 1)
                        else:
                            c = (new_symbol, r, trace, layer + 1)
                        wrapper = (self._calculate_weight(layer + 1, temp_rules, c[1]),
                                   ComparableWrapper(c))
                        q.put(wrapper)
                    else:
                        for r in new_rules:
                            wrapper = (self._calculate_weight(layer + 1, temp_rules, r),
                                       ComparableWrapper((new_symbol, r, trace, layer + 1)))
                            q.put(wrapper)
            if leaf is not None and iter_depth <= 0 and final_target is None \
                    and isinstance(leaf[1], Expression) and self._is_constant(leaf[1], temp_rules):
                final_target = leaf
            if q.qsize() == 0 and final_target is None:
                final_target = leaf
            if leaf is not None:
                cached.append(leaf)

        symbol, final_expr, traces = final_target
        # trace back after reaching the expected bottom
        return self._trace_back(final_expr, traces, cached, temp_rules)

    """
    The helper to sort the rules of the same level, we use weight to represent
    the priorities of each type of rules of each layer
    """
    def _calculate_weight(self, layer, temp_rules, rule):
        if self._is_constant(rule, temp_rules):
            return layer * 10000 + 1
        return 2 + layer * 10000


class ComparableWrapper:
    """
    Helper class to wrap the sorting, since Expression doesn't implement
    __lt__ method
    """
    def __init__(self, value):
        self.value = value

    def get_value(self):
        return self.value

    def __lt__(self, _):
        return True
