"""
Files specified for observing individual tests
"""

from lang.symb_eval import Evaluator
from lang.ast import *
from verification.verifier import is_valid
from synthesis.synth import Synthesizer
from lang.paddle import parse
from lark import exceptions
import os
from pathlib import Path
from z3 import *
if __name__ == "__main__":
    f_name = "%s/examples/even.paddle" % Path(__file__).parent.absolute()
    ast = parse(f_name)
    ev = Evaluator({})
    # exp = ev.evaluate(ast)
    # print(exp)
    # # print([str(x) for x in exp.children()])
    # # print([type(x).__name__ for x in exp.children()])
    # print(is_valid(exp))
    syn = Synthesizer(ast)

    print([str(e) for e in syn.synth_method_2().values()])
    # print([str(e) for e in syn.synth_method_1().values()])
    for i in range(5000):
        syn.synth_method_2()
