"""
CSC410 Final Project: Enumerative Synthesizer
by Victor Nicolet and Danya Lette

Fill in this file to complete the verification portion
of the assignment.
"""

from typing import Any
from z3 import *
from lang.ast import *


def is_valid(formula: Expression) -> bool:
    """
    Returns true if the formula is valid.

    """
    # It should return true if the formula is valid.
    # To check that the formula is valid, you should use the Z3 api

    """

    # Details:

    z3 --> model the possible combination of solutions

    - find all variables, add constraints

    - iterate all grammer rules

        - iterate all production rules

            - convert rule and expression to z3 and add constraint to model

    - recursively and expression for assignment, parse the operator according to each iteration stacks

    - assign variable Expr to Int or Bool of z3

    - constant to real numbers

    - apply smt solver in z3

    - see details and run custom.py

    """
    smt_solver = is_valid_helper(formula)
    solver = Solver()
    solver.add(Not(smt_solver))
    resp = solver.check()

    return str(resp) != "sat"


"""
A helper function to recursively convert the Expression to Z3 classes
"""


def is_valid_helper(formula: Expression) -> Any:
    if isinstance(formula, IntConst):
        return formula.value
    elif isinstance(formula, BoolConst):
        return formula.value
    elif isinstance(formula, BinaryExpr):
        operator = formula.operator
        op = str(operator)
        eval_str = ""
        # start evaluation according to different operator
        if str(operator) == "=":
            eval_str = "is_valid_helper(formula.left_operand)" + "==" + "is_valid_helper(formula.right_operand)"
        elif str(operator) == "&&":
            eval_str = "And(" + "is_valid_helper(formula.left_operand)" + "," + "is_valid_helper(formula.right_operand)" + ")"
        elif str(operator) == "||":
            eval_str = "Or(" + "is_valid_helper(formula.left_operand)" + "," + "is_valid_helper(formula.right_operand)" + ")"
        else:
            eval_str = "is_valid_helper(formula.left_operand)" + op + "is_valid_helper(formula.right_operand)"
        return eval(eval_str)
    elif isinstance(formula, VarExpr):
        if str(formula.var.type) == "int":
            return Int(formula.name)
        elif str(formula.var.type) == "bool":
            return Bool(formula.name)
    elif isinstance(formula, Ite):
        # Ite is the same as If in z3
        check_expr = formula.cond
        true_then = formula.true_br
        false_then = formula.false_br
        return If(is_valid_helper(check_expr), is_valid_helper(true_then), is_valid_helper(false_then))
    elif isinstance(formula, UnaryExpr):
        op = str(formula.operator)
        opprand = formula.operand
        if op == "!":
            return Not(eval("is_valid_helper(opprand)"))
        elif op == "abs":
            # absolute values should be represented as If
            v = is_valid_helper(opprand)
            return If(v > 0, v, -v)
        return eval(op + "is_valid_helper(opprand)")
