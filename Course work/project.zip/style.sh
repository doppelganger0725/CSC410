#!/bin/bash
# check style lint script
python3 -m flake8 . --count --exit-zero --max-line-length=127 --ignore F,W503,W504,E722