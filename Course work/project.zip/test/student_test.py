from lang.symb_eval import EvaluationUndefinedHoleError, Evaluator
from lang.ast import *
import unittest
from random import randint
from lang.paddle import parse
from lang import paddle
from lark import exceptions
from lang.transformer import TransformerVariableException
from verification.verifier import is_valid
from synthesis.synth import Synthesizer
from typing import Mapping
import os
from pathlib import Path
"""
Test case includs student 8 custom paddle file, shows as repeat test(test 1-5)
Each of the new paddle file is considered as new test case 16 test including default
"""


def Augment_check_well_formed(prog: Program, hole_map: Mapping[str, Expression]) -> bool:
    """
    Checks that a hole completion is well-formed:

    - the hole completion should be a dictionary with keys: hole ids and data: Expressions.

    - each key of the dictionary should be a string,

    - each value should be an Expression

    NEW

    - the number of hole in program equal to the number of hole in the hole_map

    - each Expression should be pure, that is, there is no grammar symbol left in it, and there
    is no grammar expression left in it.
    """
    if not isinstance(prog, Program):
        return False
    if not isinstance(hole_map, dict):
        return False
    for hole_id, hole_completion in hole_map.items():
        # the keys should be strings
        if not isinstance(hole_id, str):
            return False
        # the data should be an expression
        if not isinstance(hole_completion, Expression):
            return False
        # the expression should be "pure", i.e not contain
        # any GrammarVar or GrammarInteger
        if not prog.is_pure_expression(hole_completion):
            return False
        if len(prog.holes) != len(hole_map.items()):
            return False
    return True


class TestStudent(unittest.TestCase):
    def test_sanity_student(self):
        self.assertTrue(True)

    def test_example_sum3(self):
        '''Test with undefined holes examples and basic binary expression'''
        filename = '%s/examples/sum3.paddle' % Path(
            __file__).parent.parent.absolute()
        if not os.path.exists(filename):
            raise Exception(
                "TestEval is looking for %s. Make sure file exists." % filename)

        prog: Program = parse(filename)
        empty = Evaluator({})
        # Evaluating this program with no hole definitions should raise an EvaluationUndefinedHoleError
        with self.assertRaises(EvaluationUndefinedHoleError):
            empty.evaluate(prog)
        # Assert number of input
        self.assertEqual(len(prog.inputs), 3,
                         msg="In %s, we expected exactly 3 inputs." % filename)
        # Three variable input for sum3
        x = VarExpr(prog.inputs[0])
        y = VarExpr(prog.inputs[1])
        z = VarExpr(prog.inputs[2])
        # add up 3 variable and gives expression
        exp1 = BinaryExpr(BinaryOperator.PLUS, x, y)
        exp2 = BinaryExpr(BinaryOperator.PLUS, z, exp1, )
        defined = Evaluator({"h": exp2})
        prog_res = defined.evaluate(prog)
        # The result should be an expression
        self.assertIsInstance(prog_res, Expression)
        # The expression should be a binary expression
        self.assertIsInstance(prog_res, BinaryExpr)
        # Operator should be equals
        self.assertEqual(prog_res.operator, BinaryOperator.EQUALS)
        # both expression are Binary addition
        left_exp = prog_res.left_operand
        right_exp = prog_res.right_operand
        self.assertIsInstance(left_exp, BinaryExpr)
        self.assertIsInstance(right_exp, BinaryExpr)

        # There are three variables in prog_res
        self.assertEqual(len(prog_res.uses()), 3)

    def test_verif_evaluate_result(self):
        '''Test for all paddle instance. result for parsing and evaluation
        should always be an expression. the number of input variable should
        matches the number of uses variable'''
        examples_directory = '%s/examples/verification' % Path(
            __file__).parent.parent.absolute()
        for filename in os.listdir(examples_directory):
            if filename.endswith(".paddle"):
                filename = os.path.join(examples_directory, filename)
                # Parse
                try:
                    prog = parse(filename)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Evaluate from empty
                try:
                    ev = Evaluator({})
                    prog_res = ev.evaluate(prog)
                    # The result should always be an expression
                    self.assertIsInstance(prog_res, Expression)
                    # Check the if the variable number matches
                    self.assertEqual(len(prog_res.uses()), len(prog.inputs), msg="The number of input should match")
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
            else:
                continue

    def test_example_search3(self):
        '''Test example for search algorithem, either find the input for a given modle
        or not find the item'''

        filename = '%s/examples/verification/search3.paddle' % Path(
            __file__).parent.parent.absolute()
        if not os.path.exists(filename):
            raise Exception(
                "TestEval is looking for %s. Make sure file exists." % filename)

        prog: Program = parse(filename)
        empty = Evaluator({})
        prog_res = empty.evaluate(prog)
        # The result should be an expression
        self.assertIsInstance(prog_res, Expression)
        # The expression should be a binary expression
        self.assertIsInstance(prog_res, BinaryExpr)
        # Operator or
        self.assertEqual(prog_res.operator, BinaryOperator.OR)
        # four variable in prog_res
        self.assertEqual(len(prog_res.uses()), 4)
        # set the model of variables
        model = {"x": IntConst(1), "a1": IntConst(1), "a2": IntConst(2), "a3": IntConst(3)}
        find = empty.evaluate_expr(model, prog_res.left_operand)
        not_find = empty.evaluate_expr(model, prog_res.right_operand)
        self.assertTrue(find or not_find)
        self.assertTrue(find)

    def test_example_unary_expression(self):
        '''custom paddle Test example for unary expression'''

        filename = '%s/examples/unary_boolean.paddle' % Path(
            __file__).parent.parent.absolute()
        if not os.path.exists(filename):
            raise Exception(
                "TestEval is looking for %s. Make sure file exists." % filename)
        prog = parse(filename)
        empty = Evaluator({})
        prog_res = empty.evaluate(prog)
        # The result should be an expression
        self.assertIsInstance(prog_res, Expression)
        # The expression should be a binary expression
        self.assertIsInstance(prog_res, UnaryExpr)
        # Operator or
        self.assertEqual(prog_res.operator, UnaryOperator.NOT)
        # one variable in prog_res
        self.assertEqual(len(prog_res.uses()), 1)
        # set the model of variables
        self.assertTrue(prog_res)

    def test_example_condition(self):
        '''Test with undefined holes examples with condition expression'''
        filename = '%s/examples/obfuscated_0.paddle' % Path(
            __file__).parent.parent.absolute()
        if not os.path.exists(filename):
            raise Exception(
                "TestEval is looking for %s. Make sure file exists." % filename)

        prog: Program = parse(filename)
        empty = Evaluator({})
        # Evaluating this program with no hole definitions should raise an EvaluationUndefinedHoleError
        with self.assertRaises(EvaluationUndefinedHoleError):
            empty.evaluate(prog)
        # Assert number of input
        self.assertEqual(len(prog.inputs), 4,
                         msg="In %s, we expected exactly 4 inputs." % filename)
        # Three variable input for sum3
        x1 = VarExpr(prog.inputs[0])
        x2 = VarExpr(prog.inputs[1])
        x3 = VarExpr(prog.inputs[2])
        x4 = VarExpr(prog.inputs[3])
        # add up 3 variable and gives expression
        defined = Evaluator({"h": IntConst(0)})
        prog_res = defined.evaluate(prog)
        # print(prog_res)
        # The result should be an expression
        self.assertIsInstance(prog_res, Expression)
        # The expression should be a Ite expression
        self.assertIsInstance(prog_res, Ite)

        cond1 = prog_res.cond
        true_br1 = prog_res.true_br
        false_br1 = prog_res.false_br
        # check each component of conditional expression
        self.assertIsInstance(cond1, VarExpr)
        self.assertIsInstance(true_br1, Ite)
        self.assertIsInstance(false_br1, Ite)
        # Sub expression for true branch
        t_cond = true_br1.cond
        t_true = true_br1.true_br
        t_false = true_br1.false_br
        self.assertIsInstance(t_cond, VarExpr)
        self.assertIsInstance(t_true, BinaryExpr)
        self.assertIsInstance(t_false, BinaryExpr)
        # Sub expression for false branch
        f_cond = false_br1.cond
        f_true = false_br1.true_br
        f_false = false_br1.false_br
        self.assertIsInstance(f_cond, VarExpr)
        self.assertIsInstance(f_true, BinaryExpr)
        self.assertIsInstance(f_false, BinaryExpr)

    def test_student_verif_examples_1(self):
        """
        5 test for verification
        5 student verfication test example
        tests with custom paddle file in student_verification folder
        tests covers all operations verification
        Abs_value.paddle : test for operator PLUS/ MINUS/ Lessthan / ABS
        Arith.paddle : test for multiple / divid
        Comparison.paddle : test for operator LESS/LESS euqa / NEG
        Case_distributive.paddle : test for operator condition expression on Case distributive law
        Case_distributive_false.paddle : false case cover other logical operator
        """
        examples_directory = '%s/examples/student_verification' % Path(
            __file__).parent.parent.absolute()
        for filename in os.listdir(examples_directory):
            if filename.endswith("Abs_value.paddle.paddle"):
                filename = os.path.join(examples_directory, filename)
                # Parse
                try:
                    ast = parse(filename)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Evaluate from empty
                try:
                    ev = Evaluator({})
                    final_constraint_expr = ev.evaluate(ast)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Verify
                try:
                    # Paddle names ending with false.paddle are expected to be incorrect.
                    if filename.endswith("false.paddle"):
                        self.assertFalse(is_valid(final_constraint_expr))
                    else:
                        self.assertTrue(is_valid(final_constraint_expr))
                except:
                    self.assertFalse(
                        True, "Exception was raised when verifying %s" % filename)
            else:
                continue

    def test_student_verif_examples_2(self):
        """
        5 test for verification
        5 student verfication test example
        tests with custom paddle file in student_verification folder
        tests covers all operations verification
        Abs_value.paddle : test for operator PLUS/ MINUS/ Lessthan / ABS
        Arith.paddle : test for multiple / divid
        Comparison.paddle : test for operator LESS/LESS euqa / NEG
        Case_distributive.paddle : test for operator condition expression on Case distributive law
        Case_distributive_false.paddle : false case cover other logical operator
        """
        examples_directory = '%s/examples/student_verification' % Path(
            __file__).parent.parent.absolute()
        for filename in os.listdir(examples_directory):
            if filename.endswith("Arith.paddle"):
                filename = os.path.join(examples_directory, filename)
                # Parse
                try:
                    ast = parse(filename)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Evaluate from empty
                try:
                    ev = Evaluator({})
                    final_constraint_expr = ev.evaluate(ast)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Verify
                try:
                    # Paddle names ending with false.paddle are expected to be incorrect.
                    if filename.endswith("false.paddle"):
                        self.assertFalse(is_valid(final_constraint_expr))
                    else:
                        self.assertTrue(is_valid(final_constraint_expr))
                except:
                    self.assertFalse(
                        True, "Exception was raised when verifying %s" % filename)
            else:
                continue

    def test_student_verif_examples_3(self):
        """
        5 test for verification
        5 student verfication test example
        tests with custom paddle file in student_verification folder
        tests covers all operations verification
        Abs_value.paddle : test for operator PLUS/ MINUS/ Lessthan / ABS
        Arith.paddle : test for multiple / divid
        Comparison.paddle : test for operator LESS/LESS euqa / NEG
        Case_distributive.paddle : test for operator condition expression on Case distributive law
        Case_distributive_false.paddle : false case cover other logical operator
        """
        examples_directory = '%s/examples/student_verification' % Path(
            __file__).parent.parent.absolute()
        for filename in os.listdir(examples_directory):
            if filename.endswith("Comparison.paddle"):
                filename = os.path.join(examples_directory, filename)
                # Parse
                try:
                    ast = parse(filename)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Evaluate from empty
                try:
                    ev = Evaluator({})
                    final_constraint_expr = ev.evaluate(ast)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Verify
                try:
                    # Paddle names ending with false.paddle are expected to be incorrect.
                    if filename.endswith("false.paddle"):
                        self.assertFalse(is_valid(final_constraint_expr))
                    else:
                        self.assertTrue(is_valid(final_constraint_expr))
                except:
                    self.assertFalse(
                        True, "Exception was raised when verifying %s" % filename)
            else:
                continue

    def test_student_verif_examples_4(self):
        """
        5 test for verification
        5 student verfication test example
        tests with custom paddle file in student_verification folder
        tests covers all operations verification
        Abs_value.paddle : test for operator PLUS/ MINUS/ Lessthan / ABS
        Arith.paddle : test for multiple / divid
        Comparison.paddle : test for operator LESS/LESS euqa / NEG
        Case_distributive.paddle : test for operator condition expression on Case distributive law
        Case_distributive_false.paddle : false case cover other logical operator
        """
        examples_directory = '%s/examples/student_verification' % Path(
            __file__).parent.parent.absolute()
        for filename in os.listdir(examples_directory):
            if filename.endswith("Case_distributive.paddle"):
                filename = os.path.join(examples_directory, filename)
                # Parse
                try:
                    ast = parse(filename)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Evaluate from empty
                try:
                    ev = Evaluator({})
                    final_constraint_expr = ev.evaluate(ast)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Verify
                try:
                    # Paddle names ending with false.paddle are expected to be incorrect.
                    if filename.endswith("false.paddle"):
                        self.assertFalse(is_valid(final_constraint_expr))
                    else:
                        self.assertTrue(is_valid(final_constraint_expr))
                except:
                    self.assertFalse(
                        True, "Exception was raised when verifying %s" % filename)
            else:
                continue

    def test_student_verif_examples_5(self):
        """
        5 test for verification
        5 student verfication test example
        tests with custom paddle file in student_verification folder
        tests covers all operations verification
        Abs_value.paddle : test for operator PLUS/ MINUS/ Lessthan / ABS
        Arith.paddle : test for multiple / divid
        Comparison.paddle : test for operator LESS/LESS euqa / NEG
        Case_distributive.paddle : test for operator condition expression on Case distributive law
        Case_distributive_false.paddle : false case cover other logical operator
        """
        examples_directory = '%s/examples/student_verification' % Path(
            __file__).parent.parent.absolute()
        for filename in os.listdir(examples_directory):
            if filename.endswith("Case_distributive_false.paddle"):
                filename = os.path.join(examples_directory, filename)
                # Parse
                try:
                    ast = parse(filename)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Evaluate from empty
                try:
                    ev = Evaluator({})
                    final_constraint_expr = ev.evaluate(ast)
                except:
                    self.assertFalse(
                        True, "Exception was raised when parsing %s" % filename)
                # Verify
                try:
                    # Paddle names ending with false.paddle are expected to be incorrect.
                    if filename.endswith("false.paddle"):
                        self.assertFalse(is_valid(final_constraint_expr))
                    else:
                        self.assertTrue(is_valid(final_constraint_expr))
                except:
                    self.assertFalse(
                        True, "Exception was raised when verifying %s" % filename)
            else:
                continue

    def test_enumerate_sync2_redundant_sync(self):
        """
        Check all enumerated value generated by sync method 2
        enumerated value generated by method 2 should not appear in future iteration
        test for 20 runs
        """
        base_path = Path(
            __file__).parent.parent.absolute()
        examples_directory = f"{base_path}/examples"
        for filename in os.listdir(examples_directory):
            if filename.endswith(".paddle"):
                path = os.path.join(examples_directory, filename)
                ast = None
                try:
                    ast = paddle.parse(path)
                except:
                    # In order to see the name of the malformed file in this test output:
                    self.assertFalse(True, f"Failed parsing file {filename}")
                # Initialize a Synthesizer
                s = Synthesizer(ast)
                # record each runs of hole assignment
                result = []

                for _ in range(0, 20):
                    # Call methods : 2
                    try:
                        synth_h2 = s.synth_method_2()
                    except:
                        # There might be no next program. In that case, just continue.
                        continue

                    # check if the new assignment already generated
                    self.assertTrue(synth_h2 not in result)
                    # Check that  the maps are well-formed, according to the checkwf function.
                    self.assertTrue(Augment_check_well_formed(ast, synth_h2),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    result.append(synth_h2)
            else:
                continue

    def test_enumerate_sync_3_redundant_sync(self):
        """
        Check all enumerated value generated by sync method 3
        enumerated value generated by method 3 should not appear in future iteration
        test for 100 runs
        """
        base_path = Path(
            __file__).parent.parent.absolute()
        examples_directory = f"{base_path}/examples"
        for filename in os.listdir(examples_directory):
            if filename.endswith(".paddle"):
                path = os.path.join(examples_directory, filename)
                ast = None
                try:
                    ast = paddle.parse(path)
                except:
                    # In order to see the name of the malformed file in this test output:
                    self.assertFalse(True, f"Failed parsing file {filename}")
                # Initialize a Synthesizer
                s = Synthesizer(ast)
                # Check the well-formedness of all the expressions
                prev_h3 = None
                for _ in range(0, 100):
                    try:
                        synth_h3 = s.synth_method_3()
                    except:
                        # There might be no next program. In that case, just continue.
                        continue

                    # The map returned should be different from the previous one.
                    self.assertTrue(synth_h3 != prev_h3)
                    # Check that all the maps are well-formed, according to the checkwf function
                    self.assertTrue(Augment_check_well_formed(ast, synth_h3),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    # Update the prev variables.
                    prev_h3 = synth_h3

            else:
                continue

    def test_enumerate_student_example_1(self):
        """
        Test with enumerate testing for 3 student created paddle file
        testing for programs with multiple holes
        testing for programs with holes not used
        testing for programs with invalid holes
        """
        base_path = Path(
            __file__).parent.parent.absolute()
        examples_directory = f"{base_path}/examples/student_enumerate"
        for filename in os.listdir(examples_directory):
            if filename.endswith(".paddle"):
                path = os.path.join(examples_directory, filename)
                ast = None
                try:
                    ast = paddle.parse(path)
                except:
                    # In order to see the name of the malformed file in this test output:
                    self.assertFalse(True, f"Failed parsing file {filename}")
                # Initialize a Synthesizer
                s = Synthesizer(ast)
                # Check the well-formedness of all the expressions
                prev_h1 = None
                prev_h2 = None
                prev_h3 = None
                for _ in range(0, 10):
                    # Call all the methods : 1, 2 and 3
                    try:
                        synth_h1 = s.synth_method_1()
                        synth_h2 = s.synth_method_2()
                        synth_h3 = s.synth_method_3()
                    except:
                        # There might be no next program. In that case, just continue.
                        continue

                    # The map returned should be different from the previous one.
                    self.assertFalse(synth_h1 == prev_h1 or synth_h2 == prev_h2 or synth_h3 == prev_h3,
                                     msg="The synth_method_i should return a new program at every call.")
                    # Check that all the maps are well-formed, according to the checkwf function.
                    self.assertTrue(Augment_check_well_formed(ast, synth_h1),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    self.assertTrue(Augment_check_well_formed(ast, synth_h2),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    self.assertTrue(Augment_check_well_formed(ast, synth_h3),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    # Update the prev variables.
                    prev_h1 = synth_h1
                    prev_h2 = synth_h2
                    prev_h3 = synth_h3

            else:
                continue

    def test_enumerate_student_example_2(self):
        """
        Test with enumerate testing for 3 student created paddle file
        testing for programs with multiple holes
        testing for programs with holes not used
        testing for programs with invalid holes
        """
        base_path = Path(
            __file__).parent.parent.absolute()
        examples_directory = f"{base_path}/examples/student_enumerate"
        for filename in os.listdir(examples_directory):
            if filename.endswith(".paddle"):
                path = os.path.join(examples_directory, filename)
                ast = None
                try:
                    ast = paddle.parse(path)
                except:
                    # In order to see the name of the malformed file in this test output:
                    self.assertFalse(True, f"Failed parsing file {filename}")
                # Initialize a Synthesizer
                s = Synthesizer(ast)
                # Check the well-formedness of all the expressions
                prev_h1 = None
                prev_h2 = None
                prev_h3 = None
                for _ in range(0, 10):
                    # Call all the methods : 1, 2 and 3
                    try:
                        synth_h1 = s.synth_method_1()
                        synth_h2 = s.synth_method_2()
                        synth_h3 = s.synth_method_3()
                    except:
                        # There might be no next program. In that case, just continue.
                        continue

                    # The map returned should be different from the previous one.
                    self.assertFalse(synth_h1 == prev_h1 or synth_h2 == prev_h2 or synth_h3 == prev_h3,
                                     msg="The synth_method_i should return a new program at every call.")
                    # Check that all the maps are well-formed, according to the checkwf function.
                    self.assertTrue(Augment_check_well_formed(ast, synth_h1),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    self.assertTrue(Augment_check_well_formed(ast, synth_h2),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    self.assertTrue(Augment_check_well_formed(ast, synth_h3),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    # Update the prev variables.
                    prev_h1 = synth_h1
                    prev_h2 = synth_h2
                    prev_h3 = synth_h3

            else:
                continue

    def test_enumerate_student_example_3(self):
        """
        Test with enumerate testing for 3 student created paddle file
        testing for programs with multiple holes
        testing for programs with holes not used
        testing for programs with invalid holes
        """
        base_path = Path(
            __file__).parent.parent.absolute()
        examples_directory = f"{base_path}/examples/student_enumerate"
        for filename in os.listdir(examples_directory):
            if filename.endswith(".paddle"):
                path = os.path.join(examples_directory, filename)
                ast = None
                try:
                    ast = paddle.parse(path)
                except:
                    # In order to see the name of the malformed file in this test output:
                    self.assertFalse(True, f"Failed parsing file {filename}")
                # Initialize a Synthesizer
                s = Synthesizer(ast)
                # Check the well-formedness of all the expressions
                prev_h1 = None
                prev_h2 = None
                prev_h3 = None
                for _ in range(0, 10):
                    # Call all the methods : 1, 2 and 3
                    try:
                        synth_h1 = s.synth_method_1()
                        synth_h2 = s.synth_method_2()
                        synth_h3 = s.synth_method_3()
                    except:
                        # There might be no next program. In that case, just continue.
                        continue

                    # The map returned should be different from the previous one.
                    self.assertFalse(synth_h1 == prev_h1 or synth_h2 == prev_h2 or synth_h3 == prev_h3,
                                     msg="The synth_method_i should return a new program at every call.")
                    # Check that all the maps are well-formed, according to the checkwf function.
                    self.assertTrue(Augment_check_well_formed(ast, synth_h1),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    self.assertTrue(Augment_check_well_formed(ast, synth_h2),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    self.assertTrue(Augment_check_well_formed(ast, synth_h3),
                                    msg="The synth_method should return well-formed maps from hole ids to expressions.")
                    # Update the prev variables.
                    prev_h1 = synth_h1
                    prev_h2 = synth_h2
                    prev_h3 = synth_h3
            else:
                continue
