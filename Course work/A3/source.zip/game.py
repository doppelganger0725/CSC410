import argparse
parser = argparse.ArgumentParser(description="game parser")
PLAYER1 = 1
PLAYER2 = 2
UNSET = 0
def switch_state(state):
    return state ^ 3

def solution(x, y):
    # ctl until
    whoami = [[UNSET] * (y+1) for x in range(x + 1)]
    for cx in range(x+1):
        whoami[cx][0] = PLAYER1
    for cx in range(y+1):
        whoami[0][cx] = PLAYER1
    for cx in range(min(x+1, y+1)):
        whoami[cx][cx] = PLAYER1

    whoami[0][0] = UNSET
    state = PLAYER2 # player 1 should make the initial move, so initialize 2 as the first one
    while True:
        for cx in range(x+1):
            for cy in range(y+1):
                if whoami[cx][cy] != UNSET:
                    continue
                # player 1 always make the first moves, not until
                if state == PLAYER1:
                    for nx in range(cx):
                        # since I can move in any distance
                        if whoami[nx][cy] == PLAYER2:
                            whoami[cx][cy] = PLAYER1
                
                    for ny in range(cy):
                        if whoami[cx][ny] == PLAYER2:
                            whoami[cx][cy] = PLAYER1
                    # diagonal
                    for nx in range(min(cx,cy)):
                        if whoami[cx-1-nx][cy-1-nx] == PLAYER2:
                            whoami[cx][cy] = PLAYER1
                last_is_player_1 = True
                # check winner path for 1
                for nx in range(cx):
                    if whoami[nx][cy] != PLAYER1:
                        last_is_player_1 = False

                for ny in range(cy):
                    if whoami[cx][ny] != PLAYER1:
                        last_is_player_1 = False 
                # diagonal
                for nx in range(min(cx,cy)):
                    if whoami[cx-1-nx][cy-1-nx] != PLAYER1:
                        last_is_player_1 = False
                if last_is_player_1:
                    whoami[cx][cy] = PLAYER2
        state = switch_state(state)
        if whoami[x][y] != UNSET:
            return whoami[x][y]

if __name__ == '__main__':
    parser.add_argument("x", type=int)
    parser.add_argument("y", type=int)
    args = parser.parse_known_args()
    known_args, unknown_args = args
    x = known_args.x
    y = known_args.y
    print(solution(x, y))